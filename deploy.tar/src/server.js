/**
 * OpenClaw CapRover Wrapper Server
 *
 * Production-grade wrapper that provides:
 * - Web-based setup wizard (Basic Auth protected)
 * - HTTP/WebSocket proxy with token injection
 * - Gateway lifecycle management
 * - Backup/export functionality
 */

import express from 'express';
import httpProxy from 'http-proxy';
import { createServer } from 'http';
import { spawn, execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { create as createTar } from 'tar';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Configuration
const PORT = parseInt(process.env.PORT || '18789', 10);
const INTERNAL_GATEWAY_PORT = parseInt(process.env.INTERNAL_GATEWAY_PORT || '18790', 10);
const STATE_DIR = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const WORKSPACE_DIR = process.env.OPENCLAW_WORKSPACE_DIR || path.join(STATE_DIR, 'workspace');
const SETUP_PASSWORD = process.env.SETUP_PASSWORD;

// Validate required environment
if (!SETUP_PASSWORD) {
  console.error('ERROR: SETUP_PASSWORD environment variable is required');
  process.exit(1);
}

// Ensure directories exist
fs.mkdirSync(STATE_DIR, { recursive: true });
fs.mkdirSync(WORKSPACE_DIR, { recursive: true });

/**
 * Resolve gateway token with priority: ENV > persisted file > generate new
 */
function resolveGatewayToken() {
  const envToken = process.env.OPENCLAW_GATEWAY_TOKEN?.trim();
  if (envToken) {
    return envToken;
  }

  const tokenPath = path.join(STATE_DIR, 'gateway.token');
  try {
    const existing = fs.readFileSync(tokenPath, 'utf8').trim();
    if (existing) {
      return existing;
    }
  } catch {
    // File doesn't exist, generate new
  }

  const generated = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(tokenPath, generated, { mode: 0o600 });
  return generated;
}

const GATEWAY_TOKEN = resolveGatewayToken();

// Gateway process management
let gatewayProcess = null;
let gatewayReady = false;
let gatewayStarting = false;

/**
 * Check if OpenClaw is configured (has completed onboarding)
 */
function isConfigured() {
  const configPath = path.join(STATE_DIR, 'openclaw.json');
  if (!fs.existsSync(configPath)) {
    return false;
  }

  try {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    // Check if at least one AI provider is configured
    const providers = config.providers || {};
    return Object.keys(providers).some(key => {
      const provider = providers[key];
      return provider && (provider.apiKey || provider.apikey || provider.key);
    });
  } catch {
    return false;
  }
}

/**
 * Run a command and return stdout
 */
function runCmd(cmd, args) {
  return new Promise((resolve, reject) => {
    try {
      const result = execSync(`${cmd} ${args.join(' ')}`, {
        encoding: 'utf8',
        timeout: 30000,
        env: { ...process.env, HOME: '/home/node' }
      });
      resolve(result.trim());
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Start the OpenClaw gateway process
 */
async function startGateway() {
  if (gatewayProcess || gatewayStarting) {
    return;
  }

  gatewayStarting = true;
  console.log('Starting OpenClaw gateway...');

  try {
    // Sync token to config
    await runCmd('openclaw', ['config', 'set', 'gateway.auth.token', GATEWAY_TOKEN]);
    await runCmd('openclaw', ['config', 'set', 'gateway.auth.mode', 'token']);
  } catch (err) {
    console.warn('Could not sync gateway config:', err.message);
  }

  // Spawn gateway bound to localhost only
  gatewayProcess = spawn('openclaw', [
    'gateway', 'run',
    '--bind', 'loopback',
    '--port', String(INTERNAL_GATEWAY_PORT),
    '--auth', 'token',
    '--token', GATEWAY_TOKEN
  ], {
    env: {
      ...process.env,
      HOME: '/home/node',
      OPENCLAW_STATE_DIR: STATE_DIR,
      OPENCLAW_WORKSPACE_DIR: WORKSPACE_DIR
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });

  gatewayProcess.stdout.on('data', (data) => {
    const output = data.toString();
    console.log('[gateway]', output.trim());
    if (output.includes('Gateway listening') || output.includes('listening on')) {
      gatewayReady = true;
    }
  });

  gatewayProcess.stderr.on('data', (data) => {
    console.error('[gateway:err]', data.toString().trim());
  });

  gatewayProcess.on('exit', (code, signal) => {
    console.log(`Gateway exited with code ${code}, signal ${signal}`);
    gatewayProcess = null;
    gatewayReady = false;
    gatewayStarting = false;

    // Auto-restart if configured and not intentionally stopped
    if (isConfigured() && signal !== 'SIGTERM') {
      console.log('Restarting gateway in 5 seconds...');
      setTimeout(startGateway, 5000);
    }
  });

  // Wait for gateway to be ready
  await new Promise((resolve) => {
    const checkReady = setInterval(() => {
      if (gatewayReady) {
        clearInterval(checkReady);
        resolve();
      }
    }, 100);

    // Timeout after 30 seconds
    setTimeout(() => {
      clearInterval(checkReady);
      resolve();
    }, 30000);
  });

  gatewayStarting = false;
  console.log('Gateway started successfully');
}

/**
 * Stop the gateway process
 */
function stopGateway() {
  if (gatewayProcess) {
    gatewayProcess.kill('SIGTERM');
    gatewayProcess = null;
    gatewayReady = false;
  }
}

// Express app setup
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files for setup wizard
app.use('/setup/static', express.static(path.join(__dirname, 'public')));

/**
 * Basic Auth middleware for setup endpoints
 */
function basicAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Basic ')) {
    res.setHeader('WWW-Authenticate', 'Basic realm="OpenClaw Setup"');
    return res.status(401).send('Authentication required');
  }

  const credentials = Buffer.from(authHeader.slice(6), 'base64').toString();
  const [username, password] = credentials.split(':');

  // Accept any username, only password matters
  if (password !== SETUP_PASSWORD) {
    res.setHeader('WWW-Authenticate', 'Basic realm="OpenClaw Setup"');
    return res.status(401).send('Invalid credentials');
  }

  next();
}

// Setup routes (protected by Basic Auth)
app.get('/setup', basicAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'setup.html'));
});

app.get('/setup/api/status', basicAuth, async (req, res) => {
  const configPath = path.join(STATE_DIR, 'openclaw.json');
  let config = {};

  try {
    config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  } catch {
    // No config yet
  }

  res.json({
    configured: isConfigured(),
    gatewayRunning: gatewayReady,
    gatewayToken: GATEWAY_TOKEN,
    stateDir: STATE_DIR,
    providers: Object.keys(config.providers || {}),
    channels: Object.keys(config.channels || {})
  });
});

app.post('/setup/api/run', basicAuth, async (req, res) => {
  const { providers } = req.body;

  if (!providers || Object.keys(providers).length === 0) {
    return res.status(400).json({ error: 'At least one provider is required' });
  }

  try {
    // Stop gateway if running
    stopGateway();

    // Configure providers
    for (const [name, config] of Object.entries(providers)) {
      if (config.apiKey) {
        await runCmd('openclaw', ['config', 'set', `providers.${name}.apiKey`, config.apiKey]);
      }
      if (config.baseUrl) {
        await runCmd('openclaw', ['config', 'set', `providers.${name}.baseUrl`, config.baseUrl]);
      }
      if (config.model) {
        await runCmd('openclaw', ['config', 'set', `providers.${name}.model`, config.model]);
      }
    }

    // Set gateway configuration
    await runCmd('openclaw', ['config', 'set', 'gateway.auth.mode', 'token']);
    await runCmd('openclaw', ['config', 'set', 'gateway.auth.token', GATEWAY_TOKEN]);
    await runCmd('openclaw', ['config', 'set', 'gateway.controlUi.allowInsecureAuth', 'true']);

    // Configure trusted proxies for reverse proxy setup
    await runCmd('openclaw', ['config', 'set', 'gateway.trustedProxies', '["127.0.0.0/8","10.0.0.0/8","172.16.0.0/12","192.168.0.0/16"]']);

    // Start gateway
    await startGateway();

    res.json({
      success: true,
      message: 'Configuration saved and gateway started',
      gatewayToken: GATEWAY_TOKEN
    });
  } catch (err) {
    console.error('Setup error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/setup/api/channel', basicAuth, async (req, res) => {
  const { channel, config } = req.body;

  if (!channel || !config) {
    return res.status(400).json({ error: 'Channel and config are required' });
  }

  try {
    for (const [key, value] of Object.entries(config)) {
      await runCmd('openclaw', ['config', 'set', `channels.${channel}.${key}`, String(value)]);
    }

    // Restart gateway to pick up new channel config
    stopGateway();
    await startGateway();

    res.json({ success: true, message: `Channel ${channel} configured` });
  } catch (err) {
    console.error('Channel config error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/setup/api/pairing/approve', basicAuth, async (req, res) => {
  const { code } = req.body;

  if (!code) {
    return res.status(400).json({ error: 'Pairing code is required' });
  }

  try {
    await runCmd('openclaw', ['gateway', 'pairing', 'approve', code]);
    res.json({ success: true, message: 'Pairing approved' });
  } catch (err) {
    console.error('Pairing approval error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/setup/api/pairing/pending', basicAuth, async (req, res) => {
  try {
    const result = await runCmd('openclaw', ['gateway', 'pairing', 'list', '--json']);
    const pending = JSON.parse(result || '[]');
    res.json({ pending });
  } catch (err) {
    // Command might not exist or return empty
    res.json({ pending: [] });
  }
});

app.post('/setup/api/reset', basicAuth, async (req, res) => {
  try {
    stopGateway();

    const configPath = path.join(STATE_DIR, 'openclaw.json');
    if (fs.existsSync(configPath)) {
      fs.unlinkSync(configPath);
    }

    res.json({ success: true, message: 'Configuration reset' });
  } catch (err) {
    console.error('Reset error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/setup/api/restart', basicAuth, async (req, res) => {
  try {
    stopGateway();
    await startGateway();
    res.json({ success: true, message: 'Gateway restarted' });
  } catch (err) {
    console.error('Restart error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/setup/export', basicAuth, async (req, res) => {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `openclaw-backup-${timestamp}.tar.gz`;

    res.setHeader('Content-Type', 'application/gzip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    await createTar(
      {
        gzip: true,
        cwd: STATE_DIR
      },
      ['.']
    ).pipe(res);
  } catch (err) {
    console.error('Export error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    configured: isConfigured(),
    gatewayReady
  });
});

// Create HTTP server
const server = createServer(app);

// Create proxy for gateway
const proxy = httpProxy.createProxyServer({
  target: `http://127.0.0.1:${INTERNAL_GATEWAY_PORT}`,
  ws: true,
  xfwd: true,
  changeOrigin: true
});

// Handle proxy errors
proxy.on('error', (err, req, res) => {
  console.error('Proxy error:', err.message);
  if (res.writeHead) {
    res.writeHead(502, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      error: 'Gateway unavailable',
      message: gatewayReady ? 'Gateway error' : 'Gateway not ready. Complete setup at /setup'
    }));
  }
});

// Inject auth token into proxied requests
proxy.on('proxyReq', (proxyReq, req) => {
  proxyReq.setHeader('Authorization', `Bearer ${GATEWAY_TOKEN}`);
  // Preserve original host for gateway
  proxyReq.setHeader('X-Forwarded-Host', req.headers.host || '');
});

// Proxy all non-setup requests to gateway
app.use('*', (req, res, next) => {
  // Skip setup routes
  if (req.originalUrl.startsWith('/setup') || req.originalUrl === '/health') {
    return next();
  }

  // Check if gateway is ready
  if (!gatewayReady) {
    // Redirect to setup if not configured
    if (!isConfigured()) {
      return res.redirect('/setup');
    }
    return res.status(503).json({
      error: 'Gateway starting...',
      message: 'Please wait a moment and refresh'
    });
  }

  proxy.web(req, res);
});

// Handle WebSocket upgrades
server.on('upgrade', (req, socket, head) => {
  // Skip setup routes
  if (req.url?.startsWith('/setup')) {
    socket.destroy();
    return;
  }

  if (!gatewayReady) {
    socket.destroy();
    return;
  }

  // Inject auth token for WebSocket
  proxy.ws(req, socket, head, {
    headers: {
      Authorization: `Bearer ${GATEWAY_TOKEN}`
    }
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down...');
  stopGateway();
  server.close(() => {
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down...');
  stopGateway();
  server.close(() => {
    process.exit(0);
  });
});

// Start server
server.listen(PORT, '0.0.0.0', async () => {
  console.log(`OpenClaw wrapper server listening on port ${PORT}`);
  console.log(`Setup wizard: http://localhost:${PORT}/setup`);
  console.log(`State directory: ${STATE_DIR}`);

  // Auto-start gateway if already configured
  if (isConfigured()) {
    console.log('Existing configuration found, starting gateway...');
    await startGateway();
  } else {
    console.log('No configuration found. Please complete setup at /setup');
  }
});
